namespace Experiments;

using System.Text.Json;

// ─── ResultWriter: записывает JSON + MD после каждого прогона ─────────────────
//
// Каждый прогон производит два файла в папке outputDir:
//   RESULT-{EXX}-scale{N}.json    ← машиночитаемый, соответствует schema
//   RESULT-{EXX}-scale{N}.md      ← человекочитаемый отчёт с таблицей
//
// Кроме того, обновляет сводный файл progress.md.

public sealed class ResultWriter
{
    // Папка куда пишем файлы. Создаётся если не существует.
    private readonly string outputDir;

    // Создать writer который пишет в указанную папку.
    // outputDir — обычно "experiments/results" внутри проекта.
    public ResultWriter(string outputDir)
    {
        this.outputDir = outputDir;
        Directory.CreateDirectory(outputDir);
    }

    // Записать результат одного прогона как JSON + MD.
    // Возвращает пути к созданным файлам.
    public OperationResult<(string JsonPath, string MdPath)> Write(
        ExperimentResult result,
        DatasetContents  dataset)
    {
        // Имена файлов: RESULT-E01-scale0.json / .md
        string baseName = $"RESULT-{result.ExperimentId}-scale{result.Scale}";
        string jsonPath = Path.Combine(outputDir, baseName + ".json");
        string mdPath   = Path.Combine(outputDir, baseName + ".md");

        try
        {
            // Записываем JSON
            string json = BuildJson(result, dataset);
            File.WriteAllText(jsonPath, json);

            // Записываем MD
            string md = BuildMarkdown(result, dataset);
            File.WriteAllText(mdPath, md);

            return OperationResult<(string, string)>.Ok((jsonPath, mdPath));
        }
        catch (Exception ex)
        {
            return OperationResult<(string, string)>.Fail(
                $"Ошибка записи результата: {ex.Message}");
        }
    }

    // Обновить сводный файл progress.md в папке outputDir.
    // Принимает все результаты всех прогонов накопленные на данный момент.
    public void UpdateProgress(IReadOnlyList<ExperimentResult> allResults)
    {
        string progressPath = Path.Combine(outputDir, "progress.md");
        File.WriteAllText(progressPath, BuildProgressMarkdown(allResults));

        string progressJson = Path.Combine(outputDir, "progress.json");
        File.WriteAllText(progressJson, BuildProgressJson(allResults));
    }

    // ─── JSON builder ────────────────────────────────────────────────────────

    private static string BuildJson(ExperimentResult r, DatasetContents d)
    {
        // Строим объект вручную чтобы контролировать порядок ключей
        // и не добавлять зависимость от Newtonsoft
        var obj = new
        {
            experiment_id = r.ExperimentId,
            scale         = r.Scale,
            tier_name     = d.TierName,
            run_at        = DateTime.UtcNow.ToString("o"),
            dataset = new
            {
                files_count   = d.Files.Count,
                total_chars   = d.TotalChars,
                approx_tokens = d.ApproxTokens,
            },
            baseline = new
            {
                accuracy_pct  = Math.Round(r.Baseline.AccuracyFraction * 100, 2),
                time_ms       = Math.Round(r.Baseline.TimeMs,  1),
                memory_mb     = Math.Round(r.Baseline.MemoryMb, 1),
                tokens        = r.Baseline.DatasetTokenCount,
            },
            enhanced = new
            {
                accuracy_pct  = Math.Round(r.Enhanced.AccuracyFraction * 100, 2),
                time_ms       = Math.Round(r.Enhanced.TimeMs,  1),
                memory_mb     = Math.Round(r.Enhanced.MemoryMb, 1),
                tokens        = r.Enhanced.DatasetTokenCount,
            },
            delta = new
            {
                // Для точности: enhanced - baseline (положительное = enhanced лучше)
                accuracy_pct_delta = Math.Round(r.AccuracyDeltaPct,  2),
                // Для времени и памяти: baseline - enhanced (положительное = enhanced быстрее/меньше)
                time_pct_saved   = TimeDelta(r),
                memory_pct_saved = MemoryDelta(r),
            },
            passed      = r.Passed,
            next_action = r.NextAction,
            notes       = r.Notes,
        };

        return JsonSerializer.Serialize(obj,
            new JsonSerializerOptions { WriteIndented = true });
    }

    // ─── Markdown builder ────────────────────────────────────────────────────

    private static string BuildMarkdown(ExperimentResult r, DatasetContents d)
    {
        string verdict = r.Passed
            ? "✅ ПРОШЁЛ → PROMOTE_TO_NEXT_SCALE"
            : "❌ НЕ ПРОШЁЛ → ABANDON или TUNE";

        double baseAcc  = Math.Round(r.Baseline.AccuracyFraction * 100, 1);
        double enhAcc   = Math.Round(r.Enhanced.AccuracyFraction * 100, 1);
        double accDelta = Math.Round(r.AccuracyDeltaPct, 1);
        double timeSave = TimeDelta(r);
        double memSave  = MemoryDelta(r);

        string accMark  = r.Passed ? "✅" : (accDelta >= 0 ? "⚠️" : "❌");
        string timeMark = timeSave >= 5 ? "✅" : timeSave >= 0 ? "⚠️" : "❌";
        string memMark  = memSave  >= 5 ? "✅" : memSave  >= 0 ? "⚠️" : "❌";

        return $"""
# {r.ExperimentId} — Scale {r.Scale}: {d.TierName}
**Запущено:** {DateTime.UtcNow:dd MMM yyyy HH:mm} UTC

## Итог: {verdict}

| Метрика | Baseline | Enhanced | Δ |
|---|---|---|---|
| Точность предсказания | {baseAcc}% | {enhAcc}% | {FormatDelta(accDelta)} {accMark} |
| Время (мс) | {Math.Round(r.Baseline.TimeMs, 0)} мс | {Math.Round(r.Enhanced.TimeMs, 0)} мс | {FormatSave(timeSave)} {timeMark} |
| Память (МБ) | {Math.Round(r.Baseline.MemoryMb, 1)} МБ | {Math.Round(r.Enhanced.MemoryMb, 1)} МБ | {FormatSave(memSave)} {memMark} |

## Датасет
- Тир: {d.TierName}
- Файлов: {d.Files.Count}
- Символов: {d.TotalChars:N0}
- Приблизительно токенов: {d.ApproxTokens:N0}

## Детали
{r.Notes}

## Что дальше
{(r.Passed
    ? $"Запустить {r.ExperimentId} на Scale {r.Scale + 1}"
    : $"Точность улучшилась только на {accDelta:+0.0;-0.0}% (нужно ≥5%). Проверить параметры.")}
""";
    }

    // ─── Progress builders ───────────────────────────────────────────────────

    private static string BuildProgressMarkdown(IReadOnlyList<ExperimentResult> results)
    {
        var lines = new System.Text.StringBuilder();
        lines.AppendLine("# Прогресс экспериментов");
        lines.AppendLine($"**Обновлено:** {DateTime.UtcNow:dd MMM yyyy HH:mm} UTC");
        lines.AppendLine();
        lines.AppendLine("| Эксп. | Scale | Точность Δ | Время Δ | Память Δ | Итог |");
        lines.AppendLine("|---|---|---|---|---|---|");

        foreach (var r in results.OrderBy(r => r.ExperimentId).ThenBy(r => r.Scale))
        {
            string verdict = r.Passed ? "✅ PASS" : "❌ FAIL";
            lines.AppendLine(
                $"| {r.ExperimentId} | {r.Scale} | " +
                $"{FormatDelta(r.AccuracyDeltaPct)} | " +
                $"{FormatSave(TimeDelta(r))} | " +
                $"{FormatSave(MemoryDelta(r))} | " +
                $"{verdict} |");
        }

        return lines.ToString();
    }

    private static string BuildProgressJson(IReadOnlyList<ExperimentResult> results)
    {
        var summary = results
            .OrderBy(r => r.ExperimentId)
            .ThenBy(r => r.Scale)
            .Select(r => new
            {
                id          = r.ExperimentId,
                scale       = r.Scale,
                accuracy_delta_pct = Math.Round(r.AccuracyDeltaPct, 2),
                passed      = r.Passed,
                next_action = r.NextAction,
            })
            .ToList();

        return JsonSerializer.Serialize(
            new { updated_at = DateTime.UtcNow.ToString("o"), experiments = summary },
            new JsonSerializerOptions { WriteIndented = true });
    }

    // ─── Вспомогательные форматирующие методы ────────────────────────────────

    // Сохранение времени: baseline - enhanced (позитивное = enhanced быстрее)
    private static double TimeDelta(ExperimentResult r)
    {
        if (r.Baseline.TimeMs <= 0) return 0;
        return Math.Round((r.Baseline.TimeMs - r.Enhanced.TimeMs) / r.Baseline.TimeMs * 100, 1);
    }

    // Сохранение памяти: baseline - enhanced (позитивное = enhanced использует меньше)
    private static double MemoryDelta(ExperimentResult r)
    {
        if (r.Baseline.MemoryMb <= 0) return 0;
        return Math.Round((r.Baseline.MemoryMb - r.Enhanced.MemoryMb) / r.Baseline.MemoryMb * 100, 1);
    }

    // Форматировать дельту точности: +18.3% или -2.1%
    private static string FormatDelta(double delta)
        => delta >= 0 ? $"+{delta:0.0}%" : $"{delta:0.0}%";

    // Форматировать экономию (время/память): быстрее 18%, медленнее 5%
    private static string FormatSave(double saved)
        => saved >= 0 ? $"быстрее/меньше {saved:0.0}%" : $"медленнее/больше {-saved:0.0}%";
}
