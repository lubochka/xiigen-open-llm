namespace Experiments;

// ─── ExperimentRunner: загружает данные → запускает → сохраняет результат ─────
//
// Это главный класс которого не хватало. Он:
//   1. Вызывает DatasetLoader.Load(scale, projectRoot) — получает реальные файлы
//   2. Токенизирует текст через символьный токенизатор (без внешних зависимостей)
//   3. Передаёт токены в нужный эксперимент (E01–E06)
//   4. Вызывает ResultWriter.Write() — пишет JSON + MD
//   5. Возвращает ExperimentResult чтобы тест мог проверить числа
//
// Пример использования:
//   var runner = new ExperimentRunner(projectRoot: "/path/to/llm_mvp_core",
//                                     outputDir:   "experiments/results");
//   var result = runner.Run("E06", scale: 0);
//   // → записал RESULT-E06-scale0.json и .md
//   // → result.Passed → true/false

public sealed class ExperimentRunner
{
    private readonly DatasetLoader       loader;
    private readonly ResultWriter        writer;
    private readonly ExperimentsDispatcher dispatcher;

    // projectRoot — корень llm_mvp_core (папка с подпроектами 00.TensorCore и т.д.)
    // outputDir   — куда писать RESULT-*.json и RESULT-*.md
    public ExperimentRunner(string projectRoot, string outputDir)
    {
        loader     = new DatasetLoader();
        writer     = new ResultWriter(outputDir);
        dispatcher = new ExperimentsDispatcher();
    }

    // Запустить один эксперимент на одном тире.
    // experimentId — "E01" .. "E06"
    // scale        — 0..5
    // projectRoot  — путь к проекту
    public OperationResult<ExperimentResult> Run(
        string experimentId,
        int    scale,
        string projectRoot)
    {
        // Шаг 1: загружаем файлы
        var loadResult = loader.Load(scale, projectRoot);
        if (!loadResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail(
                $"DatasetLoader: {loadResult.ErrorMessage}");

        DatasetContents dataset = loadResult.Value!;

        // Шаг 2: токенизируем текст
        // Используем символьный уровень (0-127 для ASCII) — не требует BPE модели.
        // Для E06 передаём сырой C# текст отдельно (Roslyn разбирает его сам).
        var tokens = CharLevelTokenize(dataset.CombinedText);

        // Шаг 3: запускаем нужный эксперимент
        OperationResult<ExperimentResult> runResult = experimentId switch
        {
            "E01" => dispatcher.RunE01(tokens),
            "E02" => dispatcher.RunE02(tokens),
            "E03" => dispatcher.RunE03(tokens),
            "E04" => dispatcher.RunE04(tokens),
            "E05" => dispatcher.RunE05(tokens),
            "E06" => dispatcher.RunE06(tokens, dataset.CombinedText),
            _     => OperationResult<ExperimentResult>.Fail(
                         $"Неизвестный эксперимент: {experimentId}"),
        };

        if (!runResult.IsSuccess)
            return runResult;

        // Шаг 4: исправляем Scale в результате (эксперименты сейчас возвращают 0)
        var result = runResult.Value! with { Scale = scale };

        // Шаг 5: пишем JSON + MD
        var writeResult = writer.Write(result, dataset);
        if (!writeResult.IsSuccess)
        {
            // Запись не удалась — но результат всё равно возвращаем (не фатально)
            Console.Error.WriteLine($"Предупреждение: {writeResult.ErrorMessage}");
        }

        return OperationResult<ExperimentResult>.Ok(result);
    }

    // Запустить эксперимент на всех тирах последовательно.
    // Останавливается при первом ABANDON (меньше 5% улучшения).
    public IReadOnlyList<ExperimentResult> RunScaleLadder(
        string experimentId,
        string projectRoot,
        int    maxScale = 5)
    {
        var results = new List<ExperimentResult>();

        for (int scale = 0; scale <= maxScale; scale++)
        {
            Console.WriteLine($"\n{experimentId} Scale {scale}: {DatasetLoader.TierNames[scale]}");

            var runResult = Run(experimentId, scale, projectRoot);

            if (!runResult.IsSuccess)
            {
                Console.WriteLine($"  Ошибка: {runResult.ErrorMessage}");
                break;
            }

            ExperimentResult result = runResult.Value!;
            results.Add(result);

            Console.WriteLine($"  Точность baseline:  {result.Baseline.AccuracyFraction * 100:F1}%");
            Console.WriteLine($"  Точность enhanced:  {result.Enhanced.AccuracyFraction * 100:F1}%");
            Console.WriteLine($"  Дельта:             {result.AccuracyDeltaPct:+0.0;-0.0}%");
            Console.WriteLine($"  Итог:               {result.NextAction}");

            if (!result.Passed)
            {
                Console.WriteLine($"  Улучшение < 5% — останавливаемся на Scale {scale}.");
                break;
            }
        }

        // Обновляем сводный progress.md
        writer.UpdateProgress(results);

        return results;
    }

    // ─── Символьная токенизация ───────────────────────────────────────────────

    // Превратить C# текст в список целых чисел (ASCII коды символов 0–127).
    // Это самый простой токенизатор — не требует BPE обучения.
    // Символы вне ASCII (> 127) заменяются на 127 (маркер "неизвестный").
    // Подходит для Марковских экспериментов на C# коде.
    private static IReadOnlyList<int> CharLevelTokenize(string text)
    {
        var tokens = new List<int>(text.Length);
        foreach (char c in text)
        {
            // Ограничиваем словарь ASCII (128 символов)
            tokens.Add(c < 128 ? (int)c : 127);
        }
        return tokens;
    }
}
