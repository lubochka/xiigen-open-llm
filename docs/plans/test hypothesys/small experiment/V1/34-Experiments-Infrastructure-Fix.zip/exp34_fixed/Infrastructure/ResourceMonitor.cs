namespace Experiments;

// ─── ResourceMonitor: замеряет память и время во время эксперимента ───────────
//
// Использует только System.Diagnostics — никаких внешних пакетов.
// Устроен как using-блок: Monitor.Start() → [эксперимент] → Monitor.Stop().
//
// Пример использования:
//   var monitor = new ResourceMonitor();
//   monitor.Start();
//   RunSomeAlgorithm();
//   var snapshot = monitor.Stop();
//   // snapshot.PeakMemoryMb, snapshot.ElapsedMs

public sealed class ResourceMonitor : IDisposable
{
    private readonly System.Diagnostics.Stopwatch stopwatch = new();
    private long memoryAtStart;
    private long peakMemoryDuringRun;
    private bool running;

    // Начать замер — вызывать перед экспериментом
    public void Start()
    {
        // Принудительная сборка мусора чтобы получить чистую базовую линию памяти
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();

        memoryAtStart     = GC.GetTotalMemory(forceFullCollection: false);
        peakMemoryDuringRun = memoryAtStart;
        running           = true;

        stopwatch.Restart();
    }

    // Зафиксировать текущую память (вызывается внутри эксперимента при желании)
    public void SampleMemory()
    {
        if (!running) return;
        long current = GC.GetTotalMemory(forceFullCollection: false);
        if (current > peakMemoryDuringRun)
            peakMemoryDuringRun = current;
    }

    // Остановить замер и вернуть снимок
    public ResourceSnapshot Stop()
    {
        stopwatch.Stop();

        // Финальный замер памяти
        long memoryAtEnd = GC.GetTotalMemory(forceFullCollection: false);
        if (memoryAtEnd > peakMemoryDuringRun)
            peakMemoryDuringRun = memoryAtEnd;

        running = false;

        return new ResourceSnapshot
        {
            ElapsedMs      = stopwatch.Elapsed.TotalMilliseconds,
            // Пик памяти выделенной именно этим экспериментом (не считая базовый процесс)
            PeakMemoryMb   = Math.Max(0, (peakMemoryDuringRun - memoryAtStart)) / 1_048_576.0,
        };
    }

    public void Dispose() { /* stopwatch не требует dispose */ }
}

// ─── Снимок ресурсов одного прогона ──────────────────────────────────────────

// Хранит то что успел замерить ResourceMonitor.
public sealed record ResourceSnapshot
{
    // Реальное прошедшее время в миллисекундах.
    public double ElapsedMs    { get; init; }

    // Пиковая память выделенная алгоритмом (сверх базовой линии), в МБ.
    public double PeakMemoryMb { get; init; }
}
