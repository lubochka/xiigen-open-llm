namespace Experiments;

// ─── DatasetLoader: читает .cs файлы проекта по уровню нагрузки ───────────────
//
// Шесть уровней нагрузки (Scale Ladder):
//   Scale 0  Markov-micro    BpeTokenizer.cs один файл             ~1 000 токенов
//   Scale 1  Markov-small    01.Tokenizer весь подпроект            ~9 100 токенов
//   Scale 2  Markov-medium   01+02+05+07+09 пять подпроектов       ~30 000 токенов
//   Scale 3  Probe-net       то же что Scale 1, передаётся в зонд-сеть
//   Scale 4  Probe-medium    то же что Scale 2, передаётся в зонд-сеть
//   Scale 5  Full            весь проект                           ~141 000 токенов
//
// DatasetLoader не знает ничего об алгоритмах — только читает файлы.
// Каждый эксперимент вызывает Load(scale, projectRoot) и получает тексты.

public sealed class DatasetLoader
{
    // Подпроекты входящие в каждый тир.
    // Ключ = номер тира (Scale), значение = папки которые включаются.
    private static readonly IReadOnlyDictionary<int, string[]> TierFolders =
        new Dictionary<int, string[]>
        {
            // Scale 0: один файл — самый маленький из подпроекта 01
            [0] = new[] { "01.Tokenizer/BpeTokenizer.cs" },

            // Scale 1: весь подпроект 01
            [1] = new[] { "01.Tokenizer" },

            // Scale 2: пять наименьших подпроектов
            [2] = new[] { "01.Tokenizer", "02.DatasetPipeline", "05.Embeddings",
                          "07.GraphEngine", "09.Inference" },

            // Scale 3 = Scale 1 (для зонд-нейросети — те же данные)
            [3] = new[] { "01.Tokenizer" },

            // Scale 4 = Scale 2 (для зонд-нейросети)
            [4] = new[] { "01.Tokenizer", "02.DatasetPipeline", "05.Embeddings",
                          "07.GraphEngine", "09.Inference" },

            // Scale 5: весь проект
            [5] = new[] { "00.TensorCore", "01.Tokenizer", "02.DatasetPipeline",
                          "03.TransformerModel", "04.TrainingLoop", "05.Embeddings",
                          "06.VectorSearch", "07.GraphEngine", "08.GraphRag",
                          "09.Inference", "10.LoRA", "11.DPO", "12.SearchEngine",
                          "13.CodeOptimizer", "14.MachineLearning" },
        };

    // Название каждого тира для отображения в отчётах
    public static readonly IReadOnlyDictionary<int, string> TierNames =
        new Dictionary<int, string>
        {
            [0] = "Markov-micro  (~1 000 токенов, 1 файл)",
            [1] = "Markov-small  (~9 100 токенов, 1 подпроект)",
            [2] = "Markov-medium (~30 000 токенов, 5 подпроектов)",
            [3] = "Probe-small   (~9 100 токенов, зонд-сеть)",
            [4] = "Probe-medium  (~30 000 токенов, зонд-сеть)",
            [5] = "Full          (~141 000 токенов, весь проект)",
        };

    // Загрузить все C# файлы для указанного тира.
    // projectRoot — корень llm_mvp_core (например "/home/user/llm_mvp_core").
    // Возвращает DatasetContents: список пар (путь к файлу, содержимое).
    public OperationResult<DatasetContents> Load(int scale, string projectRoot)
    {
        if (scale < 0 || scale > 5)
            return OperationResult<DatasetContents>.Fail(
                $"Scale должен быть от 0 до 5, получено: {scale}");

        if (!Directory.Exists(projectRoot))
            return OperationResult<DatasetContents>.Fail(
                $"Корень проекта не найден: {projectRoot}");

        var entries = new List<(string Path, string Text)>();
        var patterns = TierFolders[scale];

        foreach (string pattern in patterns)
        {
            // Паттерн может указывать на конкретный файл или на папку
            string fullPath = Path.Combine(projectRoot, pattern);

            if (File.Exists(fullPath))
            {
                // Конкретный файл (Scale 0: BpeTokenizer.cs)
                string text = File.ReadAllText(fullPath);
                if (!string.IsNullOrWhiteSpace(text))
                    entries.Add((fullPath, text));
            }
            else if (Directory.Exists(fullPath))
            {
                // Папка подпроекта — читаем все .cs файлы рекурсивно
                foreach (string csFile in Directory.EnumerateFiles(
                    fullPath, "*.cs", SearchOption.AllDirectories))
                {
                    // Пропускаем сгенерированные файлы (bin, obj, .generated.cs)
                    if (IsGeneratedFile(csFile))
                        continue;

                    string text = File.ReadAllText(csFile);
                    if (!string.IsNullOrWhiteSpace(text))
                        entries.Add((csFile, text));
                }
            }
            // Если папка/файл не найдены — тихо пропускаем (проект может быть неполным)
        }

        if (entries.Count == 0)
            return OperationResult<DatasetContents>.Fail(
                $"Scale {scale}: не найдено ни одного .cs файла в {projectRoot}. " +
                $"Ожидались папки: {string.Join(", ", patterns)}");

        // Склеиваем всё в единую последовательность для Маркова
        string allText        = string.Join("\n\n", entries.Select(e => e.Text));
        int    totalChars     = allText.Length;
        int    approxTokens   = totalChars / 4;  // грубая оценка: ~4 символа на токен

        return OperationResult<DatasetContents>.Ok(new DatasetContents
        {
            Scale          = scale,
            TierName       = TierNames[scale],
            Files          = entries.Select(e => e.Path).ToList(),
            FileTexts      = entries.ToDictionary(e => e.Path, e => e.Text),
            CombinedText   = allText,
            TotalChars     = totalChars,
            ApproxTokens   = approxTokens,
        });
    }

    // Проверить является ли файл сгенерированным (не нужен в датасете)
    private static bool IsGeneratedFile(string path)
    {
        // Пути содержащие /bin/ или /obj/ — артефакты сборки
        string normalised = path.Replace('\\', '/');
        return normalised.Contains("/bin/")  ||
               normalised.Contains("/obj/")  ||
               path.EndsWith(".g.cs")        ||
               path.EndsWith(".generated.cs");
    }
}

// ─── Результат загрузки датасета ───────────────────────────────────────────────

// Хранит все загруженные файлы и удобные агрегаты для экспериментов.
public sealed record DatasetContents
{
    // Номер тира (0–5).
    public required int Scale { get; init; }

    // Человекочитаемое название тира.
    public required string TierName { get; init; }

    // Список путей к загруженным файлам.
    public required IReadOnlyList<string> Files { get; init; }

    // Содержимое каждого файла: путь → текст.
    public required IReadOnlyDictionary<string, string> FileTexts { get; init; }

    // Все файлы склеены в один текст (разделены пустыми строками).
    // Используется экспериментами E01–E05 как единая последовательность.
    public required string CombinedText { get; init; }

    // Суммарное число символов во всех файлах.
    public required int TotalChars { get; init; }

    // Приблизительное число BPE токенов (TotalChars / 4).
    public required int ApproxTokens { get; init; }
}
