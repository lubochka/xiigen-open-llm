# 34.Experiments — Диагноз и что добавлено

## Три проблемы в реализации Claude Code

### Проблема 1: Эксперименты принимают токены снаружи — нет загрузки файлов

**Было:** каждый эксперимент принимает `IReadOnlyList<int> tokens` от вызывающего.
Никто эти токены не создаёт из реальных файлов.

```csharp
// Так было — токены берутся ниоткуда:
var result = dispatcher.RunE01(tokens);  // откуда взялись tokens?
```

**Добавлено:** `Infrastructure/DatasetLoader.cs`

```csharp
// Теперь:
var runner = new ExperimentRunner(projectRoot: "/path/to/llm_mvp_core",
                                   outputDir:   "experiments/results");
var result = runner.Run("E01", scale: 1);
// DatasetLoader читает 01.Tokenizer/*.cs, токенизирует, передаёт в E01
```

`DatasetLoader` знает шесть тиров нагрузки:

| Scale | Тир | Что читает | Примерно токенов |
|---|---|---|---|
| 0 | Markov-micro | BpeTokenizer.cs (один файл) | ~1 000 |
| 1 | Markov-small | 01.Tokenizer (весь подпроект) | ~9 100 |
| 2 | Markov-medium | 01+02+05+07+09 | ~30 000 |
| 3 | Probe-small | то же что Scale 1 | ~9 100 |
| 4 | Probe-medium | то же что Scale 2 | ~30 000 |
| 5 | Full | весь проект | ~141 000 |

---

### Проблема 2: Результаты остаются в памяти — нет JSON/MD вывода

**Было:** `ExperimentResult` возвращается из метода, дальше ничего.

**Добавлено:** `Infrastructure/ResultWriter.cs`

Каждый прогон автоматически записывает два файла:
```
experiments/results/
  RESULT-E01-scale0.json    ← машиночитаемый
  RESULT-E01-scale0.md      ← человекочитаемый
  progress.md               ← сводная таблица всех прогонов
  progress.json
```

MD отчёт содержит таблицу сравнения:
```
| Метрика | Baseline | Enhanced | Δ |
|---|---|---|---|
| Точность | 34.2% | 41.8% | +22.2% ✅ |
| Время | 45 мс | 48 мс | медленнее 6.7% ⚠️ |
| Память | 87 МБ | 12 МБ | быстрее/меньше 86.2% ✅ |
```

---

### Проблема 3: Scale всегда = 0, нет нарастающей нагрузки

**Было:** каждый эксперимент возвращает `Scale = 0` хардкодом.

**Добавлено:** `Infrastructure/ExperimentRunner.cs`

`ExperimentRunner` переопределяет Scale через `with { Scale = scale }` и
предоставляет метод `RunScaleLadder()`:

```csharp
// Запустить один эксперимент через все тиры, остановиться при < 5%
var ladder = runner.RunScaleLadder("E06", projectRoot);
// Выводит в консоль:
// E06 Scale 0: Markov-micro  (~1 000 токенов, 1 файл)
//   Точность baseline:  42.1%
//   Точность enhanced:  91.3%
//   Дельта:             +117.1%
//   Итог:               PROMOTE_TO_NEXT_SCALE
// E06 Scale 1: Markov-small  (~9 100 токенов, 1 подпроект)
//   ...
```

---

### Бонус: Memory всегда = 0

**Было:** `MemoryMb = 0` в каждом эксперименте.

**Исправлено:** заменено на `GC.GetTotalMemory(false) / 1_048_576.0` во всех шести файлах.
Добавлен `Infrastructure/ResourceMonitor.cs` для более точного замера (baseline до алгоритма, peak во время).

---

## Структура после исправлений

```
34.Experiments/
├── Core/
│   ├── ExperimentTypes.cs         — OperationResult, RunMetrics, ExperimentResult (без изменений)
│   └── MarkovChain.cs             — BigramMarkov, TrigramMarkov (без изменений)
├── Experiments/
│   ├── E01SemanticFamilies.cs     — K-Means кластеры, MemoryMb исправлен
│   ├── E02ShannonCompression.cs   — Энтропия Шеннона, MemoryMb исправлен
│   ├── E03SparseWindow.cs         — Trigramm vs bigram, MemoryMb исправлен
│   ├── E04PmiInit.cs              — PMI предсказатель, MemoryMb исправлен
│   ├── E05HierarchicalPrediction.cs — Двухуровневый Марков, MemoryMb исправлен
│   └── E06AstRoslyn.cs            — AST токены, MemoryMb исправлен
├── Infrastructure/                ← НОВАЯ ПАПКА
│   ├── DatasetLoader.cs           — читает .cs файлы по тирам
│   ├── ExperimentRunner.cs        — связывает загрузку + эксперимент + запись
│   ├── ResourceMonitor.cs         — точный замер памяти (Start/Stop)
│   └── ResultWriter.cs            — пишет JSON + MD после каждого прогона
└── ExperimentsDispatcher.cs       — (без изменений)
```

## Как использовать

```csharp
// Самый простой способ — запустить один эксперимент:
var runner = new ExperimentRunner(
    projectRoot: @"C:\path\to\llm_mvp_core",
    outputDir:   @"experiments\results");

var result = runner.Run("E06", scale: 0);
// Записывает experiments/results/RESULT-E06-scale0.json + .md

// Запустить по всем тирам до первого ABANDON:
var ladder = runner.RunScaleLadder("E06", projectRoot: @"C:\...");
// Запускает Scale 0 → 1 → 2 → ... пока accuracy >= 5%
// После каждого Scale пишет файл, в конце обновляет progress.md
```

*34.Experiments v1.1 — Infrastructure добавлена*
