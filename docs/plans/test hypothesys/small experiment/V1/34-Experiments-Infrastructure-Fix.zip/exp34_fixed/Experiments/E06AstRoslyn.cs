using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

namespace Experiments;

// ─── E06: Roslyn AST node-type tokens vs flat BPE tokens ─────────────────────

// Hypothesis: replacing raw BPE tokens with C# AST SyntaxKind enum values
// shrinks the vocabulary from ~800 BPE token types to ~40 AST node types,
// making the Markov transition matrix 400× smaller (40×40 = 1 600 vs 640 000).
// Because C# grammar is deterministic (MethodDeclaration almost always precedes
// ParameterList), the AST-level Markov should have 80–95% accuracy.
//
// Baseline: bigram Markov on raw BPE integer token IDs.
// Enhanced: bigram Markov on normalised SyntaxKind integer IDs (0..N-1).
public sealed class E06AstRoslyn
{
    // Run Scale-0 experiment.
    // 'bpeTokens' is the BPE-encoded token sequence (used as the baseline).
    // 'csharpSourceCode' is the raw C# source text (used to extract AST tokens).
    public OperationResult<ExperimentResult> Run(
        IReadOnlyList<int> bpeTokens,
        string             csharpSourceCode)
    {
        if (bpeTokens.Count < 10)
            return OperationResult<ExperimentResult>.Fail("Too few BPE tokens for E06");
        if (string.IsNullOrWhiteSpace(csharpSourceCode))
            return OperationResult<ExperimentResult>.Fail("Empty C# source for E06");

        // ── Baseline: bigram on BPE tokens ───────────────────────────────────────
        var t0      = System.Diagnostics.Stopwatch.GetTimestamp();
        int splitAt = (int)(bpeTokens.Count * 0.8);
        var bpeTrain = bpeTokens.Take(splitAt).ToList();
        var bpeVal   = bpeTokens.Skip(splitAt).ToList();

        var baseBigram = new BigramMarkov();
        baseBigram.Train(bpeTrain);
        var baseAccResult = baseBigram.Evaluate(bpeVal);
        if (!baseAccResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("Baseline eval: " + baseAccResult.ErrorMessage);

        double baselineMs = ElapsedMs(t0);

        // ── Enhanced: parse AST → normalise SyntaxKind IDs → bigram ──────────────
        var t1 = System.Diagnostics.Stopwatch.GetTimestamp();

        // Parse the C# source into a Roslyn syntax tree.
        var syntaxTree = CSharpSyntaxTree.ParseText(csharpSourceCode);
        var root       = syntaxTree.GetRoot();

        // Walk all descendant nodes and collect their SyntaxKind integer values.
        // We use DescendantNodes() (not DescendantNodesAndTokens()) to get
        // structural nodes only, skipping leaf tokens like identifiers and literals.
        var rawKinds = root.DescendantNodes()
            .Select(node => (int)node.Kind())
            .ToList();

        if (rawKinds.Count < 4)
            return OperationResult<ExperimentResult>.Fail("Too few AST nodes in source");

        // Normalise: map each distinct SyntaxKind value to a compact 0-based index.
        // This turns sparse enum values (e.g. 8651, 8800, …) into 0, 1, 2, … N-1.
        var uniqueKinds = rawKinds.Distinct().OrderBy(x => x).ToList();
        var kindToIndex = uniqueKinds
            .Select((kind, idx) => (kind, idx))
            .ToDictionary(pair => pair.kind, pair => pair.idx);

        var astTokens = rawKinds.Select(k => kindToIndex[k]).ToList();

        // Split AST tokens 80/20 the same way.
        int astSplit   = (int)(astTokens.Count * 0.8);
        var astTrain   = astTokens.Take(astSplit).ToList();
        var astVal     = astTokens.Skip(astSplit).ToList();

        if (astVal.Count < 2)
        {
            // Not enough AST nodes after split — use a single eval window.
            astTrain = astTokens.Take(astTokens.Count - 1).ToList();
            astVal   = astTokens.Skip(1).ToList();
        }

        var enhBigram = new BigramMarkov();
        var trainRes  = enhBigram.Train(astTrain);
        if (!trainRes.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("Enhanced train: " + trainRes.ErrorMessage);

        var enhAccResult = enhBigram.Evaluate(astVal);
        if (!enhAccResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("Enhanced eval: " + enhAccResult.ErrorMessage);

        double enhancedMs = ElapsedMs(t1);

        return OperationResult<ExperimentResult>.Ok(new ExperimentResult
        {
            ExperimentId = "E06",
            Scale        = 0,
            Baseline = new RunMetrics
            {
                AccuracyFraction  = baseAccResult.Value,
                TimeMs            = baselineMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = bpeTokens.Count
            },
            Enhanced = new RunMetrics
            {
                AccuracyFraction  = enhAccResult.Value,
                TimeMs            = enhancedMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = astTokens.Count
            },
            Notes = $"bpeVocab={baseBigram.VocabSize}, astNodeTypes={uniqueKinds.Count}, astNodes={astTokens.Count}"
        });
    }

    private static double ElapsedMs(long t0)
        => (System.Diagnostics.Stopwatch.GetTimestamp() - t0)
           / (double)System.Diagnostics.Stopwatch.Frequency * 1000.0;
}
