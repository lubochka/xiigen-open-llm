namespace Experiments;

// ─── E02: Shannon entropy of BPE tokens vs cluster IDs ────────────────────────

// Hypothesis: replacing BPE token IDs (vocabulary ~800) with K-Means cluster IDs
// (vocabulary ~50) reduces the Shannon entropy of the token stream by 30–50%.
// Lower entropy means the stream is more compressible — fewer bits per token.
//
// Baseline: Shannon entropy of the raw BPE token sequence.
// Enhanced: Shannon entropy of the cluster-ID sequence derived via K-Means (K=50).
//
// Shannon entropy H = –Σ p_i × log2(p_i) in bits per token.
// This experiment does NOT use a Markov matrix — entropy is a direct measure.
public sealed class E02ShannonCompression
{
    private const int K = 50;

    // Run Scale-0 experiment on the provided token sequence.
    public OperationResult<ExperimentResult> Run(IReadOnlyList<int> tokens)
    {
        if (tokens.Count < 10)
            return OperationResult<ExperimentResult>.Fail("Too few tokens for E02");

        int splitAt = (int)(tokens.Count * 0.8);
        var train = tokens.Take(splitAt).ToList();

        // ── Baseline: Shannon entropy of raw BPE tokens ─────────────────────────
        var t0           = System.Diagnostics.Stopwatch.GetTimestamp();
        double baselineH = ShannonEntropy(tokens);
        double baselineMs = ElapsedMs(t0);

        // ── Enhanced: cluster IDs via K-Means ───────────────────────────────────
        var t1 = System.Diagnostics.Stopwatch.GetTimestamp();

        int vocabSize = train.Max() + 1;
        var tokenCounts = new int[vocabSize];
        var cooccur     = new int[vocabSize][];
        for (int i = 0; i < vocabSize; i++) cooccur[i] = new int[vocabSize];

        for (int i = 0; i < train.Count; i++)
        {
            tokenCounts[train[i]]++;
            if (i < train.Count - 1) cooccur[train[i]][train[i + 1]]++;
        }

        var seenTokens = Enumerable.Range(0, vocabSize)
            .Where(t => tokenCounts[t] > 0)
            .ToList();

        int k = Math.Min(K, seenTokens.Count);

        var features = seenTokens
            .Select(t =>
            {
                double total = tokenCounts[t];
                return cooccur[t].Select(c => c / total).ToArray();
            })
            .ToList();

        var kmeans    = new MachineLearning.KMeansAlgorithm();
        var fitResult = kmeans.Fit(features, k, maxIterations: 50);
        if (!fitResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("K-Means: " + fitResult.ErrorMessage);

        int[] assignments = fitResult.Value!;
        var tokenToCluster = new Dictionary<int, int>();
        for (int i = 0; i < seenTokens.Count; i++)
            tokenToCluster[seenTokens[i]] = assignments[i];

        var clusterIds = tokens
            .Select(t => tokenToCluster.GetValueOrDefault(t, 0))
            .ToList();

        double enhancedH  = ShannonEntropy(clusterIds);
        double enhancedMs = ElapsedMs(t1);

        // Normalise entropy to a 0–1 "accuracy proxy" for the common result schema.
        // Lower entropy = better compression, so we invert: accuracy = 1 – H/Hmax.
        // Hmax for BPE vocab: log2(vocabSize).  Hmax for clusters: log2(k).
        double hMaxBaseline = vocabSize > 1 ? Math.Log2(vocabSize) : 1.0;
        double hMaxEnhanced = k > 1         ? Math.Log2(k)         : 1.0;

        // Fraction of maximum possible entropy that is NOT used — higher is sparser/more compressible.
        double baselineSparse = 1.0 - baselineH / hMaxBaseline;
        double enhancedSparse = 1.0 - enhancedH / hMaxEnhanced;

        return OperationResult<ExperimentResult>.Ok(new ExperimentResult
        {
            ExperimentId = "E02",
            Scale        = 0,
            Baseline = new RunMetrics
            {
                AccuracyFraction  = Math.Clamp(baselineSparse, 0, 1),
                TimeMs            = baselineMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = tokens.Count
            },
            Enhanced = new RunMetrics
            {
                AccuracyFraction  = Math.Clamp(enhancedSparse, 0, 1),
                TimeMs            = enhancedMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = tokens.Count
            },
            Notes = $"baselineEntropy={baselineH:F3} bits, enhancedEntropy={enhancedH:F3} bits, K={k}"
        });
    }

    // Shannon entropy H = –Σ p_i × log2(p_i) in bits per token.
    public static double ShannonEntropy(IReadOnlyList<int> tokens)
    {
        if (tokens.Count == 0) return 0.0;

        var counts = new Dictionary<int, int>();
        foreach (int t in tokens)
            counts[t] = counts.GetValueOrDefault(t, 0) + 1;

        double n = tokens.Count;
        double h = 0.0;
        foreach (int c in counts.Values)
        {
            double p = c / n;
            h -= p * Math.Log2(p);
        }
        return h;
    }

    private static double ElapsedMs(long t0)
        => (System.Diagnostics.Stopwatch.GetTimestamp() - t0)
           / (double)System.Diagnostics.Stopwatch.Frequency * 1000.0;
}
