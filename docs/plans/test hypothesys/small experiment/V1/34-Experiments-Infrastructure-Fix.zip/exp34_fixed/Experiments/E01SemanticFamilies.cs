namespace Experiments;

// ─── E01: Semantic token families via K-Means clustering ──────────────────────

// Hypothesis: grouping BPE tokens into 50 semantic clusters reduces the Markov
// transition matrix from ~800×800 (640 000 cells) to ~50×50 (2 500 cells).
// A Markov chain on cluster IDs should have higher per-cluster accuracy because
// cluster transitions are more deterministic than raw BPE token transitions.
//
// Baseline: bigram Markov on raw BPE integer token IDs.
// Enhanced: K-Means (K=50) on one-hot frequency vectors → bigram on cluster IDs.
public sealed class E01SemanticFamilies
{
    // Number of K-Means clusters (semantic families).
    private const int K = 50;

    // Run Scale-0 experiment on the provided token sequence.
    // The list is split 80/20 into training and validation subsets.
    public OperationResult<ExperimentResult> Run(IReadOnlyList<int> tokens)
    {
        if (tokens.Count < 10)
            return OperationResult<ExperimentResult>.Fail("Too few tokens for E01");

        // Split into train (first 80%) and validation (last 20%).
        int splitAt = (int)(tokens.Count * 0.8);
        var train = tokens.Take(splitAt).ToList();
        var val   = tokens.Skip(splitAt).ToList();

        // ── Baseline: raw bigram on BPE token IDs ──────────────────────────────
        var t0 = System.Diagnostics.Stopwatch.GetTimestamp();
        var baselineMarkov = new BigramMarkov();
        var trainResult = baselineMarkov.Train(train);
        if (!trainResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("Baseline train: " + trainResult.ErrorMessage);

        var baselineAcc = baselineMarkov.Evaluate(val);
        if (!baselineAcc.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("Baseline eval: " + baselineAcc.ErrorMessage);

        double baselineMs = ElapsedMs(t0);

        // ── Enhanced: K-Means clustering → bigram on cluster IDs ──────────────

        // Build co-occurrence frequency feature vector for each unique token:
        // for token t, the feature vector is its row in the bigram count matrix
        // normalised by the total occurrences of t.  This encodes "who follows t"
        // as a probability distribution → semantically similar tokens cluster.
        var t1 = System.Diagnostics.Stopwatch.GetTimestamp();

        int vocabSize = train.Max() + 1;

        // Count how many times each token appears and who follows it.
        var tokenCounts = new int[vocabSize];
        var cooccur     = new int[vocabSize][];
        for (int i = 0; i < vocabSize; i++) cooccur[i] = new int[vocabSize];

        for (int i = 0; i < train.Count; i++)
        {
            tokenCounts[train[i]]++;
            if (i < train.Count - 1) cooccur[train[i]][train[i + 1]]++;
        }

        // Build normalised feature vectors only for tokens that actually appear.
        var seenTokens = Enumerable.Range(0, vocabSize)
            .Where(t => tokenCounts[t] > 0)
            .ToList();

        // When there are very few unique tokens, cap K at their count.
        int k = Math.Min(K, seenTokens.Count);

        var featureVectors = seenTokens
            .Select(t =>
            {
                double total = tokenCounts[t];
                return cooccur[t].Select(c => c / total).ToArray();
            })
            .ToList();

        // Run K-Means on the feature vectors.
        var kmeans = new MachineLearning.KMeansAlgorithm();
        var fitResult = kmeans.Fit(featureVectors, k, maxIterations: 50);
        if (!fitResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("K-Means: " + fitResult.ErrorMessage);

        int[] assignments = fitResult.Value!;

        // Map each seen token to its cluster ID.
        var tokenToCluster = new Dictionary<int, int>();
        for (int i = 0; i < seenTokens.Count; i++)
            tokenToCluster[seenTokens[i]] = assignments[i];

        // Convert train and val sequences to cluster ID sequences.
        // Tokens not seen in training map to cluster 0 (safest fallback).
        var trainClusters = train.Select(t => tokenToCluster.GetValueOrDefault(t, 0)).ToList();
        var valClusters   = val.Select(t => tokenToCluster.GetValueOrDefault(t, 0)).ToList();

        // Build bigram on cluster IDs.
        var enhancedMarkov = new BigramMarkov();
        var enhTrainResult = enhancedMarkov.Train(trainClusters);
        if (!enhTrainResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("Enhanced train: " + enhTrainResult.ErrorMessage);

        var enhancedAcc = enhancedMarkov.Evaluate(valClusters);
        if (!enhancedAcc.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("Enhanced eval: " + enhancedAcc.ErrorMessage);

        double enhancedMs = ElapsedMs(t1);

        // ── Assemble result ────────────────────────────────────────────────────
        return OperationResult<ExperimentResult>.Ok(new ExperimentResult
        {
            ExperimentId = "E01",
            Scale        = 0,
            Baseline = new RunMetrics
            {
                AccuracyFraction  = baselineAcc.Value,
                TimeMs            = baselineMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = tokens.Count
            },
            Enhanced = new RunMetrics
            {
                AccuracyFraction  = enhancedAcc.Value,
                TimeMs            = enhancedMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = tokens.Count
            },
            Notes = $"K={k}, vocabSize={vocabSize}, seenTokens={seenTokens.Count}"
        });
    }

    private static double ElapsedMs(long t0)
        => (System.Diagnostics.Stopwatch.GetTimestamp() - t0)
           / (double)System.Diagnostics.Stopwatch.Frequency * 1000.0;
}
