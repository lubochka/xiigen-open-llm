namespace Experiments;

// ─── E05: Two-level hierarchical Markov chain ─────────────────────────────────

// Hypothesis: predicting "1 of 2 000 BPE tokens" flat is expensive.
// Splitting into two steps — first predict the cluster, then predict the token
// within the predicted cluster — uses far less memory (two small matrices instead
// of one giant matrix) with only a small accuracy loss.
//
// Level 1: cluster transition matrix (K×K = 2 500 cells for K=50).
// Level 2: per-cluster token transition matrix (K matrices each ~40×40).
// Total: K² + K×40² = 2 500 + 80 000 = 82 500 cells vs 2 000² = 4 000 000 flat.
//
// Baseline: single-level bigram Markov on raw BPE token IDs.
// Enhanced: two-level hierarchical Markov using K-Means clusters (K=50).
public sealed class E05HierarchicalPrediction
{
    private const int K = 50;

    // Run Scale-0 experiment on the provided token sequence.
    public OperationResult<ExperimentResult> Run(IReadOnlyList<int> tokens)
    {
        if (tokens.Count < 10)
            return OperationResult<ExperimentResult>.Fail("Too few tokens for E05");

        int splitAt = (int)(tokens.Count * 0.8);
        var train = tokens.Take(splitAt).ToList();
        var val   = tokens.Skip(splitAt).ToList();

        // ── Baseline: flat bigram ─────────────────────────────────────────────────
        var t0 = System.Diagnostics.Stopwatch.GetTimestamp();
        var bigram = new BigramMarkov();
        bigram.Train(train);

        int baseCorrect = 0, baseTotal = val.Count - 1;
        for (int i = 0; i < baseTotal; i++)
        {
            var pred = bigram.Predict(val[i]);
            if (pred.IsSuccess && pred.Value == val[i + 1]) baseCorrect++;
        }
        double baselineAcc = baseTotal > 0 ? baseCorrect / (double)baseTotal : 0.0;
        double baselineMs  = ElapsedMs(t0);

        // ── Enhanced: two-level hierarchical Markov ───────────────────────────────
        var t1 = System.Diagnostics.Stopwatch.GetTimestamp();

        // Build token→cluster mapping via K-Means on co-occurrence features.
        int vocabSize = train.Max() + 1;
        var tokenCounts = new int[vocabSize];
        var cooccur     = new int[vocabSize][];
        for (int i = 0; i < vocabSize; i++) cooccur[i] = new int[vocabSize];

        for (int i = 0; i < train.Count; i++)
        {
            tokenCounts[train[i]]++;
            if (i < train.Count - 1) cooccur[train[i]][train[i + 1]]++;
        }

        var seenTokens = Enumerable.Range(0, vocabSize)
            .Where(t => tokenCounts[t] > 0).ToList();

        int k = Math.Min(K, seenTokens.Count);

        var features = seenTokens
            .Select(t =>
            {
                double tot = tokenCounts[t];
                return cooccur[t].Select(c => c / tot).ToArray();
            })
            .ToList();

        var kmeans    = new MachineLearning.KMeansAlgorithm();
        var fitResult = kmeans.Fit(features, k, maxIterations: 50);
        if (!fitResult.IsSuccess)
            return OperationResult<ExperimentResult>.Fail("K-Means: " + fitResult.ErrorMessage);

        int[] assignments = fitResult.Value!;
        var tokenToCluster = new Dictionary<int, int>();
        for (int i = 0; i < seenTokens.Count; i++)
            tokenToCluster[seenTokens[i]] = assignments[i];

        // Convert training tokens to cluster IDs.
        var trainClusters = train.Select(t => tokenToCluster.GetValueOrDefault(t, 0)).ToList();

        // Build Level-1: cluster → cluster transition (bigram on cluster IDs).
        var clusterBigram = new BigramMarkov();
        clusterBigram.Train(trainClusters);

        // Build Level-2: for each cluster, bigram on raw tokens belonging to that cluster.
        // clusterMembers[c] = list of all token IDs assigned to cluster c.
        var clusterMembers = new Dictionary<int, List<int>>();
        for (int c = 0; c < k; c++) clusterMembers[c] = [];
        foreach (var t in seenTokens)
            clusterMembers[tokenToCluster[t]].Add(t);

        // Map each raw token ID to a local index within its cluster.
        // Local indices are 0..clusterSize-1 so each per-cluster bigram
        // has a small, dense vocabulary.
        var tokenToLocal = new Dictionary<int, int>();
        foreach (var (c, members) in clusterMembers)
            for (int idx = 0; idx < members.Count; idx++)
                tokenToLocal[members[idx]] = idx;

        // Build a per-cluster bigram on the local-index token sequence.
        // We walk the training sequence and emit a local-index pair whenever two
        // consecutive tokens both belong to the predicted cluster.
        var withinBigrams = new BigramMarkov?[k];
        for (int c = 0; c < k; c++)
        {
            // Collect all consecutive pairs where both tokens are in cluster c.
            var localSeq = new List<int>();
            for (int i = 0; i < train.Count; i++)
            {
                if (tokenToCluster.GetValueOrDefault(train[i], -1) == c)
                    localSeq.Add(tokenToLocal[train[i]]);
            }
            if (localSeq.Count >= 2)
            {
                var wb = new BigramMarkov();
                wb.Train(localSeq);
                withinBigrams[c] = wb;
            }
        }

        // Evaluate two-level prediction on the validation set.
        // For each position i, predict:
        //   1. The cluster of token[i+1] using clusterBigram(cluster[i]).
        //   2. The local index within that predicted cluster using withinBigrams.
        //   3. Map the local index back to a raw token.
        // Count a correct prediction only when the final raw token matches val[i+1].
        int enhCorrect = 0, enhTotal = val.Count - 1;
        for (int i = 0; i < enhTotal; i++)
        {
            int curToken   = val[i];
            int curCluster = tokenToCluster.GetValueOrDefault(curToken, 0);

            // Step 1: predict cluster.
            var clusterPred = clusterBigram.Predict(curCluster);
            if (!clusterPred.IsSuccess) continue;
            int predCluster = clusterPred.Value;

            // Step 2: predict local index within predicted cluster.
            var wb = withinBigrams[predCluster];
            int predLocal = 0;
            if (wb is not null)
            {
                int curLocal = tokenToLocal.GetValueOrDefault(curToken, 0);
                var localPred = wb.Predict(curLocal);
                if (localPred.IsSuccess) predLocal = localPred.Value;
            }

            // Step 3: map local index back to raw token.
            var members = clusterMembers[predCluster];
            if (predLocal < members.Count)
            {
                int predToken = members[predLocal];
                if (predToken == val[i + 1]) enhCorrect++;
            }
        }

        double enhancedAcc = enhTotal > 0 ? enhCorrect / (double)enhTotal : 0.0;
        double enhancedMs  = ElapsedMs(t1);

        return OperationResult<ExperimentResult>.Ok(new ExperimentResult
        {
            ExperimentId = "E05",
            Scale        = 0,
            Baseline = new RunMetrics
            {
                AccuracyFraction  = baselineAcc,
                TimeMs            = baselineMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = tokens.Count
            },
            Enhanced = new RunMetrics
            {
                AccuracyFraction  = enhancedAcc,
                TimeMs            = enhancedMs,
                MemoryMb          = GC.GetTotalMemory(false) / 1_048_576.0,
                DatasetTokenCount = tokens.Count
            },
            Notes = $"K={k}, vocabSize={vocabSize}"
        });
    }

    private static double ElapsedMs(long t0)
        => (System.Diagnostics.Stopwatch.GetTimestamp() - t0)
           / (double)System.Diagnostics.Stopwatch.Frequency * 1000.0;
}
