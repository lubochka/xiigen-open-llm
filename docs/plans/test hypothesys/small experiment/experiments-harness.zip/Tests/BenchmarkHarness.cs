using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;

// BenchmarkHarness измеряет пять метрик для пары (baseline, enhanced) на маленьком датасете.
// Датасет = один подпроект проекта (~10 файлов, ~200-1500 строк кода).
// Зонд-модель = 2 слоя, 64 измерения, 4 головы, 100 шагов. Прогон занимает секунды.
//
// Запуск:
//   var harness = new BenchmarkHarness();
//   var result = harness.Run("E01", scale: 0);
//   harness.WriteJson(result, "docs/experiments/E01-semantic-tokens/RESULT-E01-scale0.json");
//   harness.WriteMarkdown(result, "docs/experiments/E01-semantic-tokens/RESULT-E01-scale0.md");
namespace LlmFromScratch.Tests
{
    // ProbeResult хранит все пять метрик одного прогона (baseline или enhanced).
    public sealed record ProbeResult
    {
        // Процент правильных предсказаний следующего токена на валидационном срезе (0-100)
        public double Accuracy  { get; init; }

        // Реальное время от старта до конца 100 шагов обучения + оценки, миллисекунды
        public long   TimeMs    { get; init; }

        // Пик рабочего множества процесса за всё время прогона, мегабайты
        public double MemoryMb  { get; init; }

        // Суммарное время процессора потраченное за прогон, миллисекунды
        public double CpuMs     { get; init; }

        // Суммарный объём временных файлов (шарды, чекпоинты) записанных за прогон, килобайты
        public double DiskKb    { get; init; }
    }

    // DeltaResult вычисляет разницу между baseline и enhanced.
    // Положительное значение всегда означает "enhanced лучше".
    public sealed record DeltaResult
    {
        // (enhanced - baseline) / baseline × 100. Больше = enhanced точнее.
        public double AccuracyPct { get; init; }

        // (baseline - enhanced) / baseline × 100. Больше = enhanced быстрее.
        public double TimePct     { get; init; }

        // (baseline - enhanced) / baseline × 100. Больше = enhanced использует меньше памяти.
        public double MemoryPct   { get; init; }

        // (baseline - enhanced) / baseline × 100. Больше = enhanced использует меньше CPU.
        public double CpuPct      { get; init; }

        // (baseline - enhanced) / baseline × 100. Больше = enhanced пишет меньше на диск.
        public double DiskPct     { get; init; }

        // Вычислить дельту из двух результатов
        public static DeltaResult Compute(ProbeResult baseline, ProbeResult enhanced)
        {
            // Вспомогательная функция: delta "меньше = лучше" (время, память, CPU, диск)
            static double LessIsBetter(double b, double e)
                => b == 0 ? 0 : Math.Round((b - e) / b * 100, 2);

            // Вспомогательная функция: delta "больше = лучше" (accuracy)
            static double MoreIsBetter(double b, double e)
                => b == 0 ? 0 : Math.Round((e - b) / b * 100, 2);

            return new DeltaResult
            {
                AccuracyPct = MoreIsBetter(baseline.Accuracy, enhanced.Accuracy),
                TimePct     = LessIsBetter(baseline.TimeMs,   enhanced.TimeMs),
                MemoryPct   = LessIsBetter(baseline.MemoryMb, enhanced.MemoryMb),
                CpuPct      = LessIsBetter(baseline.CpuMs,    enhanced.CpuMs),
                DiskPct     = LessIsBetter(baseline.DiskKb,   enhanced.DiskKb)
            };
        }
    }

    // ExperimentRun описывает один полный прогон: датасет, конфиг, baseline, enhanced, итог.
    public sealed record ExperimentRun
    {
        public string      Id           { get; init; } = "";
        public string      Name         { get; init; } = "";
        public string      RunAt        { get; init; } = DateTime.UtcNow.ToString("O");
        public int         Scale        { get; init; }
        public DatasetInfo Dataset      { get; init; } = new();
        public ProbeConfig ProbeModel   { get; init; } = new();
        public ProbeResult Baseline     { get; init; } = new();
        public ProbeResult Enhanced     { get; init; } = new();
        public DeltaResult Delta        { get; init; } = new();
        public bool        Passed       { get; init; }
        public string      Notes        { get; init; } = "";
        public string      NextAction   { get; init; } = "";
    }

    public sealed record DatasetInfo
    {
        public string SourceProject { get; init; } = "";
        public int    Files         { get; init; }
        public int    Lines         { get; init; }
        public int    TokensBpe     { get; init; }
    }

    public sealed record ProbeConfig
    {
        // Эти значения одинаковы для всех экспериментов
        public int Layers         { get; init; } = 2;
        public int HiddenDim      { get; init; } = 64;
        public int Heads          { get; init; } = 4;
        public int ContextLength  { get; init; } = 64;
        public int TrainingSteps  { get; init; } = 100;
        public int BatchSize      { get; init; } = 8;
    }

    // BenchmarkHarness запускает оба варианта и собирает метрики.
    public sealed class BenchmarkHarness
    {
        // Порог улучшения в процентах — эксперимент считается прошедшим
        private const double PassThresholdPct = 5.0;

        // Запустить зонд-модель и собрать все пять метрик.
        // Этот метод вызывается дважды — для baseline и для enhanced конфигурации.
        //
        // datasetFiles — список .cs файлов которые служат обучающим датасетом
        // tokenizeAndTrain — функция которая токенизирует данные и обучает зонд 100 шагов
        //                    она отличается между baseline и enhanced (разный токенизатор / архитектура)
        // Returns ProbeResult со всеми пятью метриками
        public static ProbeResult Measure(
            IReadOnlyList<string> datasetFiles,
            Func<IReadOnlyList<string>, (double accuracy, long tempBytesWritten)> tokenizeAndTrain)
        {
            // Записать стартовые значения метрик процесса
            var process   = Process.GetCurrentProcess();
            process.Refresh();
            double cpuStartMs = process.TotalProcessorTime.TotalMilliseconds;

            // Отметить временные файлы которые уже существуют до прогона
            long diskStartBytes = MeasureExistingTempBytes();

            // Сбросить пик рабочего множества измеряя его до старта
            // (не все платформы поддерживают сброс — берём baseline до старта)
            long memBeforeBytes = process.WorkingSet64;

            // Запустить реальный секундомер
            var stopwatch = Stopwatch.StartNew();

            // Выполнить токенизацию + 100 шагов обучения + оценку
            // Эта функция реализуется отдельно для каждого эксперимента
            var (accuracy, tempBytesWritten) = tokenizeAndTrain(datasetFiles);

            // Остановить секундомер
            stopwatch.Stop();

            // Считать финальные метрики
            process.Refresh();
            double cpuEndMs  = process.TotalProcessorTime.TotalMilliseconds;
            long   memPeak   = process.PeakWorkingSet64;

            return new ProbeResult
            {
                Accuracy  = Math.Round(accuracy * 100, 2),
                TimeMs    = stopwatch.ElapsedMilliseconds,
                MemoryMb  = Math.Round(memPeak / 1_048_576.0, 1),
                CpuMs     = Math.Round(cpuEndMs - cpuStartMs, 1),
                DiskKb    = Math.Round((tempBytesWritten - diskStartBytes) / 1024.0, 1)
            };
        }

        // Определить прошёл ли эксперимент — все пять метрик должны улучшиться на ≥5%
        public static bool IsAllPassing(DeltaResult delta)
            => delta.AccuracyPct >= PassThresholdPct
            && delta.TimePct     >= PassThresholdPct
            && delta.MemoryPct   >= PassThresholdPct
            && delta.CpuPct      >= PassThresholdPct
            && delta.DiskPct     >= PassThresholdPct;

        // Записать результат в JSON файл
        public static void WriteJson(ExperimentRun run, string outputPath)
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented             = true,
                PropertyNamingPolicy      = JsonNamingPolicy.SnakeCaseLower,
                DefaultIgnoreCondition    = JsonIgnoreCondition.WhenWritingNull
            };

            var json = JsonSerializer.Serialize(run, options);

            // Создать директорию если не существует
            var dir = Path.GetDirectoryName(outputPath);
            if (dir != null && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            File.WriteAllText(outputPath, json);
        }

        // Записать результат в Markdown файл для человека
        public static void WriteMarkdown(ExperimentRun run, string outputPath)
        {
            static string Fmt(double? v, string unit)
                => v.HasValue ? $"{v:F1} {unit}" : "—";

            static string DeltaFmt(double v)
            {
                if (v >= 5)  return $"**+{v:F1}%** ✅";
                if (v >= 0)  return $"+{v:F1}%";
                return $"{v:F1}% ⚠️";
            }

            var md = $"""
# {run.Id} — {run.Name}
Scale {run.Scale} · {run.Dataset.SourceProject} · {run.Dataset.Files} files · {run.Dataset.Lines} lines · run: {run.RunAt[..10]}

## Result: {(run.Passed ? "✅ All metrics passed" : "🔄 Pending / ❌ Not all passed")}

| Metric | What it measures | Baseline | Enhanced | Delta | Target ≥5%? |
|--------|-----------------|---------|---------|-------|-------------|
| Top-1 accuracy | % of next-token predictions correct | {Fmt(run.Baseline.Accuracy, "%")} | {Fmt(run.Enhanced.Accuracy, "%")} | {DeltaFmt(run.Delta.AccuracyPct)} | {(run.Delta.AccuracyPct >= 5 ? "✅" : "—")} |
| Time | wall-clock time for 100 steps | {Fmt(run.Baseline.TimeMs, "ms")} | {Fmt(run.Enhanced.TimeMs, "ms")} | {DeltaFmt(run.Delta.TimePct)} | {(run.Delta.TimePct >= 5 ? "✅" : "—")} |
| Memory | peak RAM during training | {Fmt(run.Baseline.MemoryMb, "MB")} | {Fmt(run.Enhanced.MemoryMb, "MB")} | {DeltaFmt(run.Delta.MemoryPct)} | {(run.Delta.MemoryPct >= 5 ? "✅" : "—")} |
| CPU | total processor time | {Fmt(run.Baseline.CpuMs, "ms")} | {Fmt(run.Enhanced.CpuMs, "ms")} | {DeltaFmt(run.Delta.CpuPct)} | {(run.Delta.CpuPct >= 5 ? "✅" : "—")} |
| Disk | bytes written to temp files | {Fmt(run.Baseline.DiskKb, "KB")} | {Fmt(run.Enhanced.DiskKb, "KB")} | {DeltaFmt(run.Delta.DiskPct)} | {(run.Delta.DiskPct >= 5 ? "✅" : "—")} |

## Notes
{(string.IsNullOrEmpty(run.Notes) ? "—" : run.Notes)}

## Next step
{run.NextAction}
""";
            File.WriteAllText(outputPath, md);
        }

        // Измерить сколько байт уже занято временными файлами до прогона.
        // Сравнение до/после даёт объём записанный этим прогоном.
        private static long MeasureExistingTempBytes()
        {
            var tempDir = Path.Combine(Path.GetTempPath(), "llm_probe");
            if (!Directory.Exists(tempDir)) return 0;
            return Directory
                .GetFiles(tempDir, "*", SearchOption.AllDirectories)
                .Sum(f => new FileInfo(f).Length);
        }
    }
}
