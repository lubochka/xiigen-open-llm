# Experiment Harness — Micro-Scale Benchmarks
## Version 1.0 · LlmFromScratch.sln

**Принцип:** датасет = один подпроект проекта (~10 файлов, ~200–1500 строк).  
Зонд-модель = 2 слоя, 64 измерения, 4 головы, 100 шагов обучения.  
Каждый прогон занимает секунды, не часы.  
Цель на каждом эксперименте: улучшение ≥5% хотя бы по одной метрике, без деградации остальных.

---

## Почему маленький датасет лучше для начала

Большой датасет (WikiText-103, 103M токенов) прячет разницу между подходами в шум.  
Маленький датасет (один подпроект, 200–1500 строк C# кода) делает разницу видимой за 100 шагов.

Мы не измеряем "насколько хороша модель". Мы измеряем "насколько подход A лучше подхода B на одних и тех же данных за одинаковое число шагов". Для этого хватит 200 строк и 2 слоёв.

---

## Лестница масштабирования

| Масштаб | Датасет | Токенов BPE | Время прогона |
|---|---|---|---|
| Scale 0 | 1 подпроект (Tokenizer, 3 файла) | ~2,000 | 5–30 секунд |
| Scale 1 | 3 подпроекта (Tokenizer + GraphEngine + VectorSearch) | ~8,000 | 1–3 минуты |
| Scale 2 | 10 подпроектов | ~40,000 | 10–20 минут |
| Scale 3 | Всё решение (24 подпроекта) | ~200,000 | 1–2 часа |

Правило перехода: эксперимент переходит на следующий масштаб только если на текущем все метрики прошли порог ≥5% улучшения.

---

## Зонд-модель (одинаковая для всех экспериментов)

```
Слои:             2 трансформерных блока
Измерения:        64 (hidden_dim)
Головы внимания:  4
Длина контекста:  64 токена
Словарь:          определяется датасетом (символьный уровень или BPE)
Шагов обучения:   100
Батч:             8 последовательностей × 64 токена
Оптимизатор:      AdamW, lr=1e-3
```

Зонд нарочно маленький. Он не умеет генерировать хороший код — он умеет показывать разницу между подходами.

---

## Пять метрик

| Код | Название | Что измеряем | Единица | C# API |
|---|---|---|---|---|
| `accuracy` | Точность предсказания следующего токена | Топ-1 совпадение на валидационном срезе | % (0–100) | Ручной подсчёт |
| `time_ms` | Время прогона | Реальное время 100 шагов обучения + оценки | миллисекунды | `Stopwatch.ElapsedMilliseconds` |
| `memory_mb` | Пик памяти | Максимальный RSS процесса за прогон | мегабайты | `Process.GetCurrentProcess().PeakWorkingSet64 / 1048576` |
| `cpu_ms` | Время процессора | Суммарное CPU-время процесса | миллисекунды | `Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds` |
| `disk_kb` | Дисковый ввод-вывод | Байт записано во временные файлы (шарды, чекпоинты) | килобайты | `FileInfo.Length` по всем временным файлам |

### Как считается улучшение

```
delta_accuracy   = (enhanced_accuracy - baseline_accuracy) / baseline_accuracy × 100
delta_time_ms    = (baseline_time   - enhanced_time)   / baseline_time   × 100   ← меньше = лучше
delta_memory_mb  = (baseline_memory - enhanced_memory) / baseline_memory × 100   ← меньше = лучше
delta_cpu_ms     = (baseline_cpu    - enhanced_cpu)    / baseline_cpu    × 100   ← меньше = лучше
delta_disk_kb    = (baseline_disk   - enhanced_disk)   / baseline_disk   × 100   ← меньше = лучше
```

Положительное число всегда означает "лучше", независимо от метрики.

---

## Шесть экспериментов

| ID | Название | Что меняем | Подпроект-датасет | Ожидаем улучшение |
|---|---|---|---|---|
| E01 | Семантические токены | BPE → объекты с FrameNet + SRL + кластер | 01.Tokenizer | accuracy +10–20% |
| E02 | Сжатие датасета | uint16 шарды → Zstandard | 02.DatasetPipeline | disk -60–80% |
| E03 | Разреженное внимание | Плотная матрица → CSR (50 из 512) | 03.TransformerModel | memory -40%, time -30% |
| E04 | SVD инициализация | Случайные веса → PMI-SVD | 04.TrainingLoop | accuracy +5–15% |
| E05 | Семьи токенов | Flat softmax → K-Means иерархия | 14.MachineLearning | time -20% |
| E06 | Компилятор-RAG | Текст → AST узлы через Roslyn | 13.CodeOptimizer | accuracy +15–25% |

---

## JSON формат результата

Каждый запуск эксперимента создаёт один JSON файл.  
Схема: `docs/experiments/schema/experiment-result.schema.json`

```json
{
  "id": "E01",
  "name": "Semantic object tokens vs standard BPE",
  "run_at": "2026-05-01T10:00:00Z",
  "scale": 0,
  "dataset": {
    "source_project": "01.Tokenizer",
    "files": 3,
    "lines": 197,
    "tokens_bpe": 2041
  },
  "probe_model": {
    "layers": 2, "hidden_dim": 64, "heads": 4,
    "context_length": 64, "training_steps": 100
  },
  "baseline": {
    "label": "Standard BPE uint16 tokens",
    "accuracy": 0.0,
    "time_ms": 0,
    "memory_mb": 0.0,
    "cpu_ms": 0,
    "disk_kb": 0
  },
  "enhanced": {
    "label": "Semantic object tokens with FrameNet frame and K-Means cluster",
    "accuracy": 0.0,
    "time_ms": 0,
    "memory_mb": 0.0,
    "cpu_ms": 0,
    "disk_kb": 0
  },
  "delta": {
    "accuracy_pct": 0.0,
    "time_pct": 0.0,
    "memory_pct": 0.0,
    "cpu_pct": 0.0,
    "disk_pct": 0.0
  },
  "passed": false,
  "notes": ""
}
```

---

## MD формат (человекочитаемый)

Каждый запуск создаёт файл `RESULT-E01-scale0.md` рядом с JSON.

```markdown
# E01 — Semantic object tokens vs standard BPE
Scale 0 · 01.Tokenizer · 3 files · 197 lines · run: 2026-05-01

## Result: ❌ / ✅ / 🔄 Pending

| Metric | Baseline | Enhanced | Delta | Target ≥5%? |
|--------|----------|----------|-------|-------------|
| Accuracy (top-1) | 0% | 0% | +0% | ❌ |
| Time | 0 ms | 0 ms | +0% | ❌ |
| Memory | 0 MB | 0 MB | +0% | ❌ |
| CPU | 0 ms | 0 ms | +0% | ❌ |
| Disk | 0 KB | 0 KB | +0% | ❌ |

## What changed
[Описание что именно было изменено]

## Notes
[Наблюдения, аномалии, выводы]

## Next step
Scale 0 passed → run Scale 1 (3 projects)
```

---

## C# класс для замеров (BenchmarkProbe)

Файл: `Tests/BenchmarkProbe.cs`

```csharp
// BenchmarkProbe запускает один прогон эксперимента и собирает все пять метрик.
// Используется одинаково для baseline и enhanced вариантов — разница только в конфигурации.
public sealed class BenchmarkProbe
{
    // Запустить зонд и вернуть измерения
    // datasetFiles — список .cs файлов которые служат обучающим датасетом
    // tokenizer    — токенизатор (baseline: BPE, enhanced: SemanticObjectTokenizer)
    // modelConfig  — конфиг зонд-модели (всегда 2 слоя, 64 dim, 100 шагов)
    public static ProbeResult Run(
        IReadOnlyList<string> datasetFiles,
        ITokenizerProvider tokenizer,
        ProbeModelConfig modelConfig)
    {
        // Запомнить стартовые метрики процесса
        var process = Process.GetCurrentProcess();
        process.Refresh();
        double cpuStart   = process.TotalProcessorTime.TotalMilliseconds;
        long   diskStart  = MeasureDiskBytes();
        var    stopwatch  = Stopwatch.StartNew();

        // --- загрузить и токенизировать датасет ---
        var allTokens = new List<int>();
        foreach (var path in datasetFiles)
        {
            var text   = File.ReadAllText(path);
            var result = tokenizer.Encode(text);
            allTokens.AddRange(result.Value!);
        }

        // Разбить на train (80%) и validation (20%)
        int splitAt     = (int)(allTokens.Count * 0.8);
        var trainTokens = allTokens.Take(splitAt).ToArray();
        var valTokens   = allTokens.Skip(splitAt).ToArray();

        // --- создать и обучить зонд-модель ---
        var model     = new ProbeModel(modelConfig);
        var optimizer = new AdamW(model.Parameters(), learningRate: 1e-3);

        for (int step = 0; step < modelConfig.TrainingSteps; step++)
        {
            // Случайный батч из тренировочных данных
            var (inputs, targets) = SampleBatch(
                trainTokens, modelConfig.ContextLength, modelConfig.BatchSize);

            // Forward → loss → backward → step
            var logits = model.Forward(inputs);
            var loss   = CrossEntropyLoss(logits, targets);
            loss.Backward();
            optimizer.Step();
            optimizer.ZeroGrad();
        }

        // --- оценить точность на валидации ---
        double top1Accuracy = EvaluateTop1Accuracy(model, valTokens, modelConfig);

        // --- собрать финальные метрики ---
        stopwatch.Stop();
        process.Refresh();

        return new ProbeResult
        {
            Accuracy  = top1Accuracy,
            TimeMs    = stopwatch.ElapsedMilliseconds,
            MemoryMb  = process.PeakWorkingSet64 / 1_048_576.0,
            CpuMs     = process.TotalProcessorTime.TotalMilliseconds - cpuStart,
            DiskKb    = (MeasureDiskBytes() - diskStart) / 1024.0
        };
    }
}
```

---

## Каталог файлов экспериментов

```
docs/experiments/
├── EXPERIMENT-HARNESS-v1.md          ← этот файл
├── EXPERIMENT-RESULTS-DASHBOARD.md  ← сводная таблица всех результатов
├── schema/
│   └── experiment-result.schema.json
├── E01-semantic-tokens/
│   ├── experiment.json               ← описание что делает эксперимент
│   ├── RESULT-E01-scale0.json        ← результат Scale 0 (заполняется при прогоне)
│   └── RESULT-E01-scale0.md         ← то же на человеческом языке
├── E02-compression/
├── E03-sparse-attention/
├── E04-svd-init/
├── E05-token-families/
└── E06-compiler-rag/
```

---

*Harness v1.0 — micro-scale benchmarks using one sub-project as dataset.*
